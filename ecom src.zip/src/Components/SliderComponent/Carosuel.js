export const CarouselData = [
  {
    image:
      "https://opencart.dostguru.com/MS03/cartsa_05/image/cache/catalog/slider/s1-1920x700.jpg",
  },
  {
    image:
      "https://opencart.dostguru.com/MS03/cartsa_05/image/cache/catalog/slider/s2-1920x700.jpg",
  },
];
